
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const HerfaApp());

class HerfaApp extends StatefulWidget {
  const HerfaApp({super.key});
  @override
  State<HerfaApp> createState() => _HerfaAppState();
}

class _HerfaAppState extends State<HerfaApp> {
  Locale _locale = const Locale('ar');
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Herfa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFFBAA06A),
        useMaterial3: true,
      ),
      locale: _locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: HomePage(
        onChangeLocale: (loc) => setState(() => _locale = loc),
        currentLocale: _locale,
      ),
    );
  }
}

enum TaskStatus { todo, doing, done }

class Task {
  String title;
  TaskStatus status;
  DateTime createdAt;
  Task(this.title, this.status) : createdAt = DateTime.now();
  Map<String, dynamic> toJson() => {
    'title': title,
    'status': status.index,
    'createdAt': createdAt.toIso8601String(),
  };
  static Task fromJson(Map<String, dynamic> m) => Task(
    m['title'] as String, TaskStatus.values[(m['status'] ?? 0) as int])
      ..createdAt = DateTime.tryParse(m['createdAt'] ?? '') ?? DateTime.now();
}

class HomePage extends StatefulWidget {
  final void Function(Locale) onChangeLocale;
  final Locale currentLocale;
  const HomePage({super.key, required this.onChangeLocale, required this.currentLocale});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _controller = TextEditingController();
  List<Task> tasks = [];
  List<Task> archive = [];
  String tr(String ar, String en) => widget.currentLocale.languageCode == 'ar' ? ar : en;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    final lastOpen = sp.getString('lastOpen');
    final todayKey = DateFormat('yyyy-MM-dd').format(DateTime.now());
    if (lastOpen != null && lastOpen != todayKey) {
      final ts = (sp.getStringList('tasks') ?? [])
          .map((e) => Task.fromJson(jsonDecode(e))).toList();
      final done = ts.where((t) => t.status == TaskStatus.done).toList();
      final notDone = ts.where((t) => t.status != TaskStatus.done).toList();
      final arch = (sp.getStringList('archive') ?? [])
          .map((e) => Task.fromJson(jsonDecode(e))).toList();
      arch.addAll(done);
      await sp.setStringList('archive', arch.map((e) => jsonEncode(e)).toList());
      await sp.setStringList('tasks', notDone.map((e) => jsonEncode(e)).toList());
    }
    sp.setString('lastOpen', todayKey);
    tasks = (sp.getStringList('tasks') ?? [])
        .map((e) => Task.fromJson(jsonDecode(e))).toList();
    archive = (sp.getStringList('archive') ?? [])
        .map((e) => Task.fromJson(jsonDecode(e))).toList();
    setState(() {});
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList('tasks', tasks.map((e) => jsonEncode(e)).toList());
    await sp.setStringList('archive', archive.map((e) => jsonEncode(e)).toList());
  }

  void _addTask() {
    final title = _controller.text.trim();
    if (title.isEmpty) return;
    setState(() {
      tasks.add(Task(title, TaskStatus.todo));
      _controller.clear();
    });
    _save();
  }

  void _exportCsv() {
    final header = ['Title','Status','Created At'];
    final lines = <List<String>>[header];
    for (final t in tasks) {
      lines.add([t.title, t.status.name, DateFormat('yyyy-MM-dd HH:mm').format(t.createdAt)]);
    }
    for (final t in archive) {
      lines.add([t.title, 'archived:'+t.status.name, DateFormat('yyyy-MM-dd HH:mm').format(t.createdAt)]);
    }
    final csv = lines.map((r)=>r.map((c)=>'"${c.replaceAll('"','""')}"').join(',')).join('\n');
    Share.share(csv, subject: tr('تصدير المهام (CSV)','Export tasks (CSV)'));
  }

  @override
  Widget build(BuildContext context) {
    final rtl = widget.currentLocale.languageCode == 'ar';
    return Directionality(
      textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Row(children: [
            Image.asset('assets/logo.png', width: 28, height: 28),
            const SizedBox(width: 8),
            const Text('Herfa'),
          ]),
          actions: [
            IconButton(onPressed: _exportCsv, icon: const Icon(Icons.ios_share)),
            PopupMenuButton<String>(
              onSelected: (v){
                if(v=='ar') widget.onChangeLocale(const Locale('ar'));
                if(v=='en') widget.onChangeLocale(const Locale('en'));
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'ar', child: Text('العربية')),
                const PopupMenuItem(value: 'en', child: Text('English')),
              ],
              icon: const Icon(Icons.language),
            )
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Row(children: [
                Expanded(child: TextField(
                  controller: _controller,
                  decoration: InputDecoration(
                    hintText: tr('أضف مهمة جديدة','Add new task'),
                    border: const OutlineInputBorder(),
                  ),
                  onSubmitted: (_)=>_addTask(),
                )),
                const SizedBox(width: 8),
                FilledButton(onPressed: _addTask, child: Text(tr('إضافة','Add'))),
              ]),
              const SizedBox(height: 12),
              Expanded(child: DefaultTabController(
                length: 4,
                child: Column(children: [
                  TabBar(tabs: [
                    Tab(text: tr('الكل','All')),
                    Tab(text: tr('غير منجز','To do')),
                    Tab(text: tr('جاري','Doing')),
                    Tab(text: tr('الأرشيف','Archive')),
                  ]),
                  Expanded(child: TabBarView(children: [
                    _buildList(tasks),
                    _buildList(tasks.where((t)=>t.status==TaskStatus.todo).toList()),
                    _buildList(tasks.where((t)=>t.status==TaskStatus.doing).toList()),
                    _buildList(archive, isArchive:true),
                  ])),
                ]),
              ))
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildList(List<Task> list, {bool isArchive=false}){
    if(list.isEmpty) return Center(child: Text(tr('لا توجد مهام','No tasks')));
    return ListView.separated(
      itemBuilder: (_,i){
        final t = list[i];
        return ListTile(
          leading: Icon(isArchive? Icons.inventory_2 : Icons.task_alt),
          title: Text(t.title),
          subtitle: Text(DateFormat('yyyy-MM-dd HH:mm').format(t.createdAt)),
          trailing: isArchive? null : _statusPicker(t),
          onLongPress: isArchive? null : (){ setState((){ list.removeAt(i); _save(); }); },
        );
      },
      separatorBuilder: (_,__)=>const Divider(height:1),
      itemCount: list.length,
    );
  }

  Widget _statusPicker(Task t){
    return DropdownButton<TaskStatus>(
      value: t.status,
      onChanged: (v){
        if(v==null) return;
        setState((){
          t.status = v;
          if(v==TaskStatus.done){ tasks.remove(t); archive.add(t); }
          _save();
        });
      },
      items: TaskStatus.values.map((s){
        final label = switch(s){
          TaskStatus.todo => tr('غير منجز','To do'),
          TaskStatus.doing => tr('جاري','Doing'),
          TaskStatus.done => tr('منجز','Done'),
        };
        return DropdownMenuItem(value: s, child: Text(label));
      }).toList(),
    );
  }
}
